import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Dialog } from "primereact/dialog";
import toast, { Toaster } from "react-hot-toast";
import { GoDotFill } from 'react-icons/go';
import { IoSearchCircle } from 'react-icons/io5';
import { IoSearch } from "react-icons/io5";

const Usermatching = () => {
    let navigate = useNavigate()
    let localamaunt = Number(localStorage.getItem("amount_store"));
    const [amaunt, getamaunt] = useState(1000);
    const [visible, setVisible] = useState(false);
    const [width, setWidth] = useState(window.innerWidth);

    // daynamicwidth get
    useEffect(() => {
        const handleResize = () => {
            setWidth(window.innerWidth);
        };

        window.addEventListener("resize", handleResize);

        // Cleanup function to remove the event listener when component unmounts
        return () => {
            window.removeEventListener("resize", handleResize);
        };
    }, [width]);

    let [stotestatus, setstotestatus] = useState()
    let got_to_live_straming = (status) => {
        setVisible(true)
        setstotestatus(status)
        console.log(status)
    }

    let setamounthandel = (event) => {
        event.preventDefault();

        if (stotestatus === true) {
            setTimeout(() => {
                toast.success("Amount Add Successfully");
                localStorage.setItem("amount_store", amaunt);
                navigate("/user_bat_mony_maching2")
                setstotestatus(null)
            }, 1000);
        } else {
            setTimeout(() => {
                toast.success("Amount Add Successfully");
                localStorage.setItem("amount_store", amaunt);
                navigate("/user_bat_mony_maching")
                setstotestatus(null)
            }, 1000);
        }


    };



    const [opacity, setOpacity] = useState(1);

    useEffect(() => {
        const animate = () => {
            setOpacity((prev) => (prev === 1 ? 0.5 : 1));
        };

        const intervalId = setInterval(animate, 500);

        return () => clearInterval(intervalId);
    }, []);

    const style = {
        lineHeight: "12px",
        color: "green",
        display: "inline-flex",
        alignItems: "center",
        opacity: opacity,
        transition: "opacity 0.5s ease-in-out"
    };

    return (
        <>
            <Toaster />
            <Dialog
                header="Deposit"
                visible={visible}
                style={{ width: `${width < 1024 ? "90%" : "50vw"}` }}
                onHide={() => {
                    if (!visible) return;
                    setVisible(false);
                }}
            >
                <p className="m-0">
                    {/* login page section */}
                    <div className="">
                        <div className="theme-box-shadow theme-border-radius theme-transparent-bg p-4 p-lg-5">
                            {/* login content */}
                            <div className="row">
                                <div className="col-12">
                                    <form className="needs-validation" noValidate>
                                        <div className="mb-3">
                                            <label className="form-label fw-bold">Amount</label>
                                            <input
                                                defaultValue={1000}
                                                onChange={(event) => getamaunt(event.target.value)}
                                                type="number"
                                                className="form-control form-control-th rounded-pill form-control form-control-th rounded-pill-th rounded-pill"
                                                id="exampleInputEmail1"
                                                required
                                            />
                                        </div>

                                        <div className="my-3">
                                            <button
                                                onClick={setamounthandel}
                                                type="submit"
                                                className="rounded-pill btn custom-btn-primary primary-btn-effect d-flex w-100 justify-content-center align-items-center"
                                                onclick="window.location.href='#';"
                                            >
                                                Click
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </p>
            </Dialog>
            
            <div className="py-5 ">
                <div className="container">
                    <div className="row animate__animated wow animate__fadeInUp mt-4">
                        <div className="col-12 text-center">
                            <p className="mt-5 mb-3 theme-text-secondary fs-4 fw-bold highlight">Live
                                Users For beting</p>
                        </div>
                        <div className='text-center mt-2'>
                            <button onClick={() => got_to_live_straming(false)} className="rounded-pill btn custom-link font-small" type="button" style={{ width: "50%" }}  >Auto Bet Matching Now</button>
                        </div>

                        {/* <div className='row justify-content-center'>
                            <div className='cil-lg-7'>
                                <h1><span>Archer</span> Vs <span>Saber</span></h1>
                                <div className="gallery">
                                    <div className="gallery">
                                        <img src="https://assets.codepen.io/1480814/archer.jpg" alt="Archer from Fate/Stay" />
                                        <img src="https://assets.codepen.io/1480814/saber.jpg" alt="Saber from Fate/Stay" />
                                    </div>
                                </div>
                            </div>
                        </div> */}

                    </div>

                    <div className="mb-3 mt-5 row justify-content-center">
                        <div className='col-lg-6 col-9' style={{ paddingRight: "0px" }}>
                            <input type="password" className="form-control form-control-th rounded-pill form-control form-control-th rounded-pill-th rounded-pill" id="exampleInputPassword1" placeholder="Search" required />
                        </div>
                        <div className='col-lg-1 col-1 ' style={{ paddingLeft: "0px" }}>
                            {/* <IoSearchCircle /> */}
                            <button className="rounded-pill btn custom-link font-small " type="button" style={{ background: "#007bff", width: "50px" }} ><IoSearch /></button>
                        </div>
                    </div>

                    <div className="row mt-4">

                        <div className="col-12" style={{ height: "400px", overflow: "scroll" }}>
                            <div className="row g-0 row blog-post-social">

                                <div className="col-md-6 col-8 d-flex justify-content-md-start justify-content-center">

                                    <ul className="post-tag-list">
                                        <li>
                                            <div className="userPic">
                                                <img src="assets/images/blog/userCommentPic.png" alt="User Pic" title="User Pic" />
                                                <span className="userName text-white " style={{ paddingLeft: "10px" }}>Fatima Taneja</span>
                                                <span style={{ lineHeight: "12px", color: "green", padding: "5px" }} className="d-inline-flex "> <GoDotFill style={style} /></span>
                                            </div>

                                        </li>

                                    </ul>
                                </div>
                                <div className="col-md-6 col-4 d-flex justify-content-md-end justify-content-center">
                                    <ul className="blog-icon-list">
                                        <li>  <button className="rounded-pill btn custom-link font-small" type="button" style={{ width: "auto" }} onClick={() => got_to_live_straming(true)} >Bet Now</button></li>
                                    </ul>
                                </div>
                            </div>
                            <div className="row g-0 row blog-post-social">
                                <div className="col-md-6 col-8 d-flex justify-content-md-start justify-content-center">
                                    <ul className="post-tag-list">
                                        <li>
                                            <div className="userPic">
                                                <img src="assets/images/blog/userCommentPic.png" alt="User Pic" title="User Pic" />
                                                <span className="userName text-white " style={{ paddingLeft: "10px" }}>Fatima Taneja</span>
                                                <span style={{ lineHeight: "12px", color: "green", padding: "5px" }} className="d-inline-flex "> <GoDotFill style={style} /></span>
                                            </div>

                                        </li>

                                    </ul>
                                </div>
                                <div className="col-md-6 col-4 d-flex justify-content-md-end justify-content-center">
                                    <ul className="blog-icon-list">
                                        <li>  <button className="rounded-pill btn custom-link font-small" type="button" style={{ width: "auto" }} onClick={() => got_to_live_straming(true)} >Bet Now</button></li>
                                    </ul>
                                </div>
                            </div>
                            <div className="row g-0 row blog-post-social">
                                <div className="col-md-6 col-8 d-flex justify-content-md-start justify-content-center">
                                    <ul className="post-tag-list">
                                        <li>
                                            <div className="userPic">
                                                <img src="assets/images/blog/userCommentPic.png" alt="User Pic" title="User Pic" />
                                                <span className="userName text-white " style={{ paddingLeft: "10px" }}>Fatima Taneja</span>
                                                <span style={{ lineHeight: "12px", color: "green", padding: "5px" }} className="d-inline-flex "> <GoDotFill style={style} /></span>
                                            </div>

                                        </li>

                                    </ul>
                                </div>
                                <div className="col-md-6 col-4 d-flex justify-content-md-end justify-content-center">
                                    <ul className="blog-icon-list">
                                        <li>  <button className="rounded-pill btn custom-link font-small" type="button" style={{ width: "auto" }} onClick={() => got_to_live_straming(true)} >Bet Now</button></li>
                                    </ul>
                                </div>
                            </div>
                            <div className="row g-0 row blog-post-social">
                                <div className="col-md-6 col-8 d-flex justify-content-md-start justify-content-center">
                                    <ul className="post-tag-list">
                                        <li>
                                            <div className="userPic">
                                                <img src="assets/images/blog/userCommentPic.png" alt="User Pic" title="User Pic" />
                                                <span className="userName text-white " style={{ paddingLeft: "10px" }}>Fatima Taneja</span>
                                                <span style={{ lineHeight: "12px", color: "green", padding: "5px" }} className="d-inline-flex "> <GoDotFill style={style} /></span>
                                            </div>

                                        </li>

                                    </ul>
                                </div>
                                <div className="col-md-6 col-4 d-flex justify-content-md-end justify-content-center">
                                    <ul className="blog-icon-list">
                                        <li>  <button className="rounded-pill btn custom-link font-small" type="button" style={{ width: "auto" }} onClick={() => got_to_live_straming(true)} >Bet Now</button></li>
                                    </ul>
                                </div>
                            </div>
                            <div className="row g-0 row blog-post-social">

                                <div className="col-md-6 col-8 d-flex justify-content-md-start justify-content-center">

                                    <ul className="post-tag-list">
                                        <li>
                                            <div className="userPic">
                                                <img src="assets/images/blog/userCommentPic.png" alt="User Pic" title="User Pic" />
                                                <span className="userName text-white " style={{ paddingLeft: "10px" }}>Fatima Taneja</span>
                                                <span style={{ lineHeight: "12px", color: "green", padding: "5px" }} className="d-inline-flex "> <GoDotFill style={style} /></span>
                                            </div>

                                        </li>

                                    </ul>
                                </div>
                                <div className="col-md-6 col-4 d-flex justify-content-md-end justify-content-center">
                                    <ul className="blog-icon-list">
                                        <li>  <button className="rounded-pill btn custom-link font-small" type="button" style={{ width: "auto" }} onClick={() => got_to_live_straming(true)} >Bet Now</button></li>
                                    </ul>
                                </div>
                            </div>
                            <div className="row g-0 row blog-post-social">
                                <div className="col-md-6 col-8 d-flex justify-content-md-start justify-content-center">
                                    <ul className="post-tag-list">
                                        <li>
                                            <div className="userPic">
                                                <img src="assets/images/blog/userCommentPic.png" alt="User Pic" title="User Pic" />
                                                <span className="userName text-white " style={{ paddingLeft: "10px" }}>Fatima Taneja</span>
                                                <span style={{ lineHeight: "12px", color: "green", padding: "5px" }} className="d-inline-flex "> <GoDotFill style={style} /></span>
                                            </div>

                                        </li>

                                    </ul>
                                </div>
                                <div className="col-md-6 col-4 d-flex justify-content-md-end justify-content-center">
                                    <ul className="blog-icon-list">
                                        <li>  <button className="rounded-pill btn custom-link font-small" type="button" style={{ width: "auto" }} onClick={() => got_to_live_straming(true)} >Bet Now</button></li>
                                    </ul>
                                </div>
                            </div>
                            <div className="row g-0 row blog-post-social">
                                <div className="col-md-6 col-8 d-flex justify-content-md-start justify-content-center">
                                    <ul className="post-tag-list">
                                        <li>
                                            <div className="userPic">
                                                <img src="assets/images/blog/userCommentPic.png" alt="User Pic" title="User Pic" />
                                                <span className="userName text-white " style={{ paddingLeft: "10px" }}>Fatima Taneja</span>
                                                <span style={{ lineHeight: "12px", color: "green", padding: "5px" }} className="d-inline-flex "> <GoDotFill style={style} /></span>
                                            </div>

                                        </li>

                                    </ul>
                                </div>
                                <div className="col-md-6 col-4 d-flex justify-content-md-end justify-content-center">
                                    <ul className="blog-icon-list">
                                        <li>  <button className="rounded-pill btn custom-link font-small" type="button" style={{ width: "auto" }} onClick={() => got_to_live_straming(true)} >Bet Now</button></li>
                                    </ul>
                                </div>
                            </div>
                            <div className="row g-0 row blog-post-social">
                                <div className="col-md-6 col-8 d-flex justify-content-md-start justify-content-center">
                                    <ul className="post-tag-list">
                                        <li>
                                            <div className="userPic">
                                                <img src="assets/images/blog/userCommentPic.png" alt="User Pic" title="User Pic" />
                                                <span className="userName text-white " style={{ paddingLeft: "10px" }}>Fatima Taneja</span>
                                                <span style={{ lineHeight: "12px", color: "green", padding: "5px" }} className="d-inline-flex "> <GoDotFill style={style} /></span>
                                            </div>

                                        </li>

                                    </ul>
                                </div>
                                <div className="col-md-6 col-4 d-flex justify-content-md-end justify-content-center">
                                    <ul className="blog-icon-list">
                                        <li>  <button className="rounded-pill btn custom-link font-small" type="button" style={{ width: "auto" }} onClick={() => got_to_live_straming(true)} >Bet Now</button></li>
                                    </ul>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>
            </div>
        </>
    )
}

export default Usermatching