import React, { useEffect, useRef, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import secureLocalStorage from "react-secure-storage";
import toast, { Toaster } from 'react-hot-toast';
import axios from 'axios';
import { ProgressSpinner } from 'primereact/progressspinner';
const Hello = () => {
    let Navigate = useNavigate()
    let [locationdata, setlocationdata] = useState({})
    const formRef = useRef(null);
    let [errorvalue, sererrorvalue] = useState({})
    let fcmtoken = secureLocalStorage.getItem("fcmtoken")
    const [showPassword, setShowPassword] = useState(false);
    const [loader, setloader] = useState(true);
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [rememberMe, setRememberMe] = useState(false);


    // show password icons
    const togglePasswordVisibility = () => {
        setShowPassword(!showPassword);
    };

    // get locatiom longitude and lattitude 
    useEffect(() => {
        // console.log("process.env.REACT_APP_SECRET_KEY", process.env.REACT_APP_SECRET_KEY)
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    let data = {
                        "lat": position.coords.latitude,
                        "lon": position.coords.longitude
                    }
                    setlocationdata(data)
                },
                (error) => {
                }
            );
        }
    }, [locationdata.lat, locationdata.lon])


    // remember me handel
    useEffect(() => {
        const rememberedEmail = secureLocalStorage.getItem('rememberedEmail');
        const rememberedPassword = secureLocalStorage.getItem('rememberedPassword');
        if (rememberedEmail && rememberedPassword) {
            setEmail(rememberedEmail);
            setPassword(rememberedPassword);
            setRememberMe(true);
        }
    }, []);


    // login handel
    let loginhandel = (e) => {
        e.preventDefault()
        let form = e.target
        let formdata = new FormData(form)
        // formdata.append("fcm_id", fcmtoken)
        // formdata.append("lat", locationdata.lat)
        // formdata.append("lang", locationdata.lon)
        let obj = Object.fromEntries(formdata.entries())
        let errors = {}
        if (obj.mobile === '' || obj.password === '') {
            if (obj.mobile === '') {
                errors = { ...errors, mobile: "mobile no. is required..." }
            }
            if (obj.password === '') {
                errors = { ...errors, password: "password is required..." }
            }
            sererrorvalue(errors)
        } else {
            setloader(false)
            if (Number(obj?.mobile?.length) == 10) {
                if (rememberMe) {
                    secureLocalStorage.setItem('rememberedEmail', obj.mobile);
                    secureLocalStorage.setItem('rememberedPassword', obj.password);
                } else {
                    secureLocalStorage.removeItem('rememberedEmail');
                    secureLocalStorage.removeItem('rememberedPassword');
                }
                // axios.post(`${process.env.REACT_APP_SECRET_KEY}/login`, formdata).then((res) => {
                //   if (res.data.result === "true") {

                //     setloader(true)
                //     toast.success("User Login Success")
                //     secureLocalStorage.setItem("u_otp", res.data.otp)
                //     secureLocalStorage.setItem("userid", res.data.userid)
                //     // secureLocalStorage.setItem("loginstatus", "true");
                //     secureLocalStorage.setItem("login_status", true)
                //     setTimeout(() => {
                //       Navigate("/");
                //     }, 500);
                //     formRef.current.reset();
                //   } else {
                //     toast.error(res.data.msg)
                //     setloader(true)
                //   }
                // }).catch((error) => {
                //   // console.log(error)
                // })
            } else {
                errors = { ...errors, num_length: "Max 10  digit ..." }
            }
            sererrorvalue(errors)
        }
    }

    // minus input handel
    const handleInput = (event) => {
        const value = event.target.value;
        if (value < 0) {
            event.target.value = "";
        }
    };


    return (
        <>
            <Toaster />
            <div className="breadcrumb-area">
                <div className="container">
                    {/* row */}
                    <div className="row ">
                        {/* col */}
                        <div className="col-12 col-lg-6 align-self-center">
                            {/* breadcrumb */}
                            <div className="page-breadcrumb">
                                <div className="mb-3">
                                    <ul className="list">
                                        <li><Link to="/">Home</Link></li>
                                        <li>Signin</li>
                                    </ul>
                                </div>
                                <h2 className="display-4 mb-0 theme-text-white font-black">Signin for Betting</h2>
                            </div>
                        </div>
                        <div className="col-12 col-lg-6 align-self-center text-center">
                            <figure className="mb-0 mt-5 pt-0 pt-lg-5 hero-image">
                                <img src="assets/images/breadcrumb/signin.png" className="img-fluid " alt="hero image" />
                            </figure>
                        </div>
                    </div>
                </div>
            </div>
            <section className="h-screen flex items-center justify-center relative overflow-hidden bg-[url('../../assets/images/hero/bg3.jpg')] bg-no-repeat bg-center bg-cover">
                <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black" />
                <div className="container">
                    <div className="grid lg:grid-cols-3 md:grid-cols-2 grid-cols-1">
                        <div className="relative overflow-hidden bg-white dark:bg-slate-900 shadow-md dark:shadow-gray-800 rounded-md">
                            <div className="p-6">
                                <Link to="/">
                                    <img
                                        src="assets/images/logo-dark.png"
                                        className="mx-auto h-[35px] block dark:hidden"
                                        alt=""
                                    />
                                    <img
                                        src="assets/images/logo-light.png"
                                        className="mx-auto h-[35px] dark:block hidden"
                                        alt=""
                                    />
                                </Link>
                                <h5 className="my-6 text-xl font-semibold">Login</h5>
                                <form onSubmit={loginhandel} className="text-start">
                                    <div className="grid grid-cols-1">
                                        <small style={{ color: "red" }} className='text-danger'>{errorvalue.fname && <>{errorvalue.fname}</>}</small>
                                        <small style={{ color: "red" }} className='text-danger'>{errorvalue.max && <>{errorvalue.max}</>}</small>
                                        <div className="mb-2 text-start">
                                            <label className="font-semibold" htmlFor="LoginEmail">
                                                Mobile No:
                                            </label>
                                            <input
                                                id="LoginEmail"
                                                type="number"
                                                className="form-input  rounded-md"
                                                maxLength="10"
                                                defaultValue={email}
                                                name='mobile'
                                                onInput={handleInput}
                                            />
                                        </div>
                                        <small style={{ color: "red" }} className='text-danger'>{errorvalue.mobile && <>{errorvalue.mobile}</>}</small>

                                        <div className="mb-2 text-start" style={{ position: "relative" }}>
                                            <label className="font-semibold" htmlFor="LoginPassword">
                                                Password:
                                            </label>
                                            <input
                                                defaultValue={password}
                                                id="LoginPassword"
                                                type={showPassword ? 'text' : 'password'}
                                                className="form-input  rounded-md"
                                                name='password'
                                            />
                                            <span style={{ position: "absolute", top: "30px", right: "10px", fontSize: "20px", cursor: "pointer" }} onClick={togglePasswordVisibility}>
                                                {showPassword ? '👁️' : '👁️‍🗨️'}
                                            </span>
                                        </div>
                                        <small style={{ color: "red" }} className='text-danger'>{errorvalue.password && <>{errorvalue.password}</>}</small>

                                        <input type="text" value={"11"} name='fcm_id' style={{ display: "none" }} />
                                        <input type="text" value={"22.66667000"} name='lat' style={{ display: "none" }} />
                                        <input type="text" value={"75.75000000"} name='lang' style={{ display: "none" }} />

                                        <div className="flex justify-between mb-4">
                                            <div className="inline-flex items-center mb-0">
                                                <input
                                                    className="form-checkbox rounded border-gray-200 dark:border-gray-800 text-emerald-600 focus:border-emerald-300 focus:ring focus:ring-offset-0 focus:ring-emerald-200 focus:ring-opacity-50 me-2"
                                                    type="checkbox"
                                                    defaultValue=""
                                                    id="RememberMe"
                                                    checked={rememberMe}
                                                    onChange={(e) => setRememberMe(e.target.checked)}
                                                />
                                                <label
                                                    className="form-checkbox-label text-slate-400"
                                                    htmlFor="RememberMe"
                                                >
                                                    Remember me
                                                </label>
                                            </div>
                                            <p className="text-slate-400 mb-0">
                                                <Link to="/forgotpassword" className="text-slate-400">
                                                    Forgot password ?
                                                </Link>
                                            </p>
                                        </div>


                                        <div className="mb-4 text-center" >
                                            {loader == true ? (
                                                <input
                                                    type="submit"
                                                    className="btn bg-emerald-600 hover:bg-emerald-700 border-emerald-600 hover:border-emerald-700 text-white rounded-md w-full"
                                                    defaultValue="Login / Sign in"
                                                />
                                            ) : (
                                                <ProgressSpinner style={{ width: '30px', height: '50px' }} strokeWidth="8" fill="var(--surface-ground)" animationDuration=".5s" />
                                            )}

                                        </div>
                                        <div className="text-center">
                                            <span className="text-slate-400 me-2">
                                                Don't have an account ?
                                            </span>{" "}
                                            <Link
                                                to="/signup"
                                                className="text-black dark:text-white font-bold"
                                            >
                                                Sign Up
                                            </Link>
                                        </div>
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </>
    )
}

export default Hello