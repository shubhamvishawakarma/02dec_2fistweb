import React from 'react'
import secureLocalStorage from 'react-secure-storage'
import Coordinator_Header from '../../Coordinator_components/Coordinator_Header'
import Header from '../pages/Header'

const Main_header = () => {
    let coordinator_loginstatus = secureLocalStorage.getItem("coordinator_loginstatus")
    console.log("coordinator_loginstatus", typeof coordinator_loginstatus)
    return (
        <div>
            {coordinator_loginstatus == true ? (
                <Coordinator_Header />
            ) : (
                <Header />
            )}
        </div>
    )
}

export default Main_header