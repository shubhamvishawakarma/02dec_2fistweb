import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import secureLocalStorage from "react-secure-storage";

const Coordinator_Header = () => {
  const navigate = useNavigate();
  let coordinator_userid = secureLocalStorage.getItem("coordinator_userid")
  let [showprofiledata, setshowprofiledata] = useState({})
  console.log(showprofiledata?.coordinatorName)

  // login handel
  let Loginhandel = () => {
    navigate("/login");
  };
  let coordinatorLoginhandel = () => {
    navigate("/coordinator_dashboard");
  };


  // get data getUser_profile
  useEffect(() => {
    let objdata = {
      "coordinatorId": coordinator_userid
    }
    axios.post("http://157.66.191.24:3051/user/api/getCoordinatorProfile", objdata).then((res) => {
      if (res.data.result == "true") {
        // console.log(res.data.data[0])
        setshowprofiledata(res.data.data[0])
      } else {

      }
    }).catch((error) => {
      if (error.response && error.response.status === 400) {
      } else {
      }
    })
  }, [])


  return (
    <>
      <header className="navbar navbar-expand-lg py-lg-0 py-2 px-0 theme-box-shadow header">
        <nav className="container">
          <a className="navbar-brand" >
            <div className="btn-wrapper">
              <Link to="/">
                <img
                  src="./logo/logonew.png"
                  className="img-fluid"
                  style={{ width: "15%" }}
                  alt="Brand Logo"
                  title="Brand Logo"
                />
              </Link>
              <button
                style={{ float: "right" }}
                className="navbar-toggler theme-bg-secondary border-0 menu-toggle"
                type="button"
                data-label="Menu"
                data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent"
                aria-expanded="false"
                aria-label="Toggle navigation"
              >
                <span className="icon-bars" />
              </button>
            </div>
          </a>

          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav ms-auto mb-2 mb-lg-0">
              {/* <li className="nav-item dropdown">
                                    <a className="nav-link nav-effect dropdown-toggle" aria-current="page" href="javascript:void(0)" id="navbarDropdown" data-bs-toggle="dropdown" aria-expanded="false" data-bs-auto-close="outside">Home</a>
                                    <ul className="dropdown-menu" aria-labelledby="navbarDropdown">
                                        <li><Link className="dropdown-item" to="/">Home Main</Link></li>
                                        <li><a className="dropdown-item" href="index-video.html">Home Video</a></li>
                                        <li><a className="dropdown-item" href="index-banner.html">Home Banner</a></li>
                                        <li><a className="dropdown-item" href="index-slider.html">Home Slider</a></li>
                                    </ul>
                                </li> */}
              <li className="nav-item">
                <Link className="nav-link nav-effect" to="/">
                  Home
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/coordinator_dashboard">
                  {
                    showprofiledata?.coordinatorProfile
                      === " " || showprofiledata?.coordinatorProfile
                      === null || showprofiledata?.coordinatorProfile
                      === undefined ? (
                      <img
                        style={{ marginTop: "4px", width: "50px", height: "50px" }}
                        alt="images"
                        className="rounded-circle"
                        src="./logo/newlogo.png"
                      />
                    ) : showprofiledata?.coordinatorProfile
                      ?.startsWith("https://") ? (
                      <img
                        style={{ marginTop: "4px", width: "50px", height: "50px" }}
                        alt="images"
                        className="rounded-circle"
                        src={`http://157.66.191.24:3051/uploads/${showprofiledata?.coordinatorProfile
                          }`}
                      />
                    ) : (
                      <img
                        style={{ marginTop: "4px", width: "50px", height: "50px" }}
                        alt="images"
                        className="rounded-circle"
                        src={`http://157.66.191.24:3051/uploads/${showprofiledata?.coordinatorProfile
                          }`}
                      />
                    )
                  }
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link nav-effect" to="/coordinator_dashboard">
                  {showprofiledata?.coordinatorName} Coordinator
                </Link>

              </li>
              {/* <lxi className="nav-item dropdown">
                <a
                  className="nav-link nav-effect dropdown-toggle"
                  href="javascript:void(0)"
                  id="navbarDropdown3"
                  data-bs-toggle="dropdown"
                  aria-expanded="false"
                >
                  Fight Coordinator
                </a>
                <ul className="dropdown-menu" aria-labelledby="navbarDropdown3">

                  <li>
                    <Link className="dropdown-item" to="/loginfightcoordinator">
                      Login/Register
                    </Link>
                  </li>
                </ul>
              </lxi> */}


              {/* <li className="nav-item">
                <Link className="nav-link nav-effect" to="/GamersVideolist">
                  Videos
                </Link>
              </li> */}
              {/* <lxi className="nav-item dropdown">
                <a
                  className="nav-link nav-effect dropdown-toggle"
                  href="javascript:void(0)"
                  id="navbarDropdown3"
                  data-bs-toggle="dropdown"
                  aria-expanded="false"
                >
                  Tournaments
                </a>
                <ul className="dropdown-menu" aria-labelledby="navbarDropdown3">
                  <li>
                    <a
                      className="dropdown-item sub"
                      href="javascript:void(0)"
                      id="navbarSubDropdown2"
                      data-bs-toggle="dropdown"
                      aria-expanded="false"
                    >
                      Betting Tournaments
                    </a>
                    <ul
                      className="dropdown-menu dropdown-submenu"
                      aria-labelledby="navbarSubDropdown2"
                    >
                      <li>
                        <Link className="dropdown-item" to="/tournaments">
                          Tournaments
                        </Link>
                      </li>
                      <li>
                        <Link
                          className="dropdown-item"
                          to="/tournamentsdetails"
                        >
                          Tournaments Details
                        </Link>
                      </li>
                    </ul>
                  </li>
                  <li>
                    <Link className="dropdown-item" to="/bets">
                      Soccer Bets
                    </Link>
                  </li>
                  <li>
                    <Link className="dropdown-item" to="/currency_bet">
                      Currency Bet
                    </Link>
                  </li>
                  <li>
                    <Link className="dropdown-item" to="/betting_details">
                      Betting Details
                    </Link>
                  </li>
                  <li>
                    <Link className="dropdown-item" to="/create_new_currency">
                      Create New Currency
                    </Link>
                  </li>
                  <li>
                    <Link className="dropdown-item" to="/Bets_fee">
                      Bets Fee
                    </Link>
                  </li>
                </ul>
              </lxi> */}

              {/* <lxi className="nav-item dropdown">
                <a
                  className="nav-link nav-effect dropdown-toggle"
                  href="javascript:void(0)"
                  id="navbarDropdown3"
                  data-bs-toggle="dropdown"
                  aria-expanded="false"
                >
                  Pages
                </a>
                <ul className="dropdown-menu" aria-labelledby="navbarDropdown3">
                  <li>
                    <Link className="dropdown-item" to="/about">
                      About Us
                    </Link>
                  </li>
                  <li>
                    <Link className="dropdown-item" to="/faq">
                      FAQ
                    </Link>
                  </li>
                  <li>
                    <Link className="dropdown-item" to="/privacy">
                      Privacy &amp; Policy
                    </Link>
                  </li>
                  <li>
                    <Link className="dropdown-item" to="/terms">
                      Terms &amp; Condition
                    </Link>
                  </li>
                  <li>
                    <Link className="dropdown-item" to="/testimonials">
                      Testimonials
                    </Link>
                  </li>
                </ul>
              </lxi> */}
              {/* <li className="nav-item dropdown">
                                <a className="nav-link nav-effect dropdown-toggle" href="javascript:void(0)" id="navbarDropdown4" data-bs-toggle="dropdown" aria-expanded="false">Blog</a>
                                <ul className="dropdown-menu" aria-labelledby="navbarDropdown4">
                                    <li><a className="dropdown-item" href="blog-grid.html">Blog Grid</a></li>
                                    <li><a className="dropdown-item" href="blog-masonry.html">Blog Masonry</a></li>
                                    <li><a className="dropdown-item" href="blog-sidebar.html">Blog Grid With Sidebar</a></li>
                                    <li><a className="dropdown-item" href="blog-details.html">Blog Details</a></li>
                                </ul> 
                            </li> */}
              {/* <li className="nav-item">
                    <Link className="nav-link nav-effect" to="/blog">
                      Blog
                    </Link>
                  </li> */}
              {/* <li className="nav-item">
                <Link className="nav-link nav-effect" to="/contact">
                  Contact
                </Link>
              </li> */}


            </ul>
            {/* <div className="d-flex ms-2 justify-content-center align-items-center position-relative">
              {loginstatus === "true" ? (
                <Link to="/dashboard">
                  <img
                    width={"50px"}
                    src="assets/images/dashboard/profile-img.png"
                    alt="images"
                    className="rounded-circle"
                  />
                </Link>
              ) : (
                <span onClick={Loginhandel} className="ms-2">
                  Login/Register
                </span>
              )}
            </div> */}

          </div>
        </nav>
      </header>
    </>
  );
};

export default Coordinator_Header;
