import axios from 'axios';
import React, { useState } from 'react';
import secureLocalStorage from 'react-secure-storage';

const Hello = () => {
    // State to track if input fields are disabled
    let userid = secureLocalStorage.getItem("userid")
    const [isDisabled, setIsDisabled] = useState(true);

    // State to manage profile data
    const [editprofiledata, seteditprofiledata] = useState({
        UserName: "test user",
        image: "test.jpeg",
        CountryName: "india",
        UserEmail: "testuser@gmail.com",
        DateOfBirth: "2001-04-14", // Update to a date format that works with input type="date"
        Gender: "male"
    });

    // Function to toggle the disabled state
    const handleEditClick = () => {
        setIsDisabled(false); // Enable the inputs when the button is clicked
    };

    // Function to handle changes in input fields
    const handleInputChange = (e) => {
        const { name, value } = e.target;
        seteditprofiledata((prevData) => ({
            ...prevData,
            [name]: value // Update the corresponding field in state
        }));
    };


    let Add_amaount_hadnel = (event) => {
        event.preventDefault();
        let objdata = {
            "userId": userid,
            "amount": "292"
        }
        console.log(objdata)
        axios.post("http://157.66.191.24:3051/user/api/addUserAmount", objdata).then((res) => {
            console.lol(res)
            // if (res.data.result == "true") {
            //     // toast.success(res.data.message)
            // } else {
            // }
        }).catch((error) => {
            if (error.response && error.response.status === 400) {
            } else {
            }
        })
    };

    return (
        <div className="theme-border-radius theme-transparent-bg p-3 ">
            <h5 className="fs-5 fw-bold mb-4" >Profile Details</h5>
            <form action="#">
                <div className="row mt-5 pt-5">
                    <div className="col-lg-6">
                        <div className="">
                            <div className="p-2 theme-transparent-bg theme-border-radius text-center">
                                <img
                                    src="assets/images/dashboard/profile-img.png"
                                    alt="images"
                                    className="rounded-circle"
                                />
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-6">
                        <div className="">
                            <button onClick={Add_amaount_hadnel}>addd amount</button>
                            <label htmlFor="perFname">User Name</label>
                            <div className="input-area">
                                <input
                                    type="text"
                                    id="perFname"
                                    name="UserName"
                                    placeholder="Enter User Name"
                                    value={editprofiledata.UserName} // Set value from state
                                    onChange={handleInputChange} // Handle change
                                    disabled={isDisabled} // Disable or enable based on state
                                />
                            </div>
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className="col-lg-6">
                        <div className="file-upload">
                            <label className="file">
                                <input
                                    type="file"
                                    name="image"
                                    disabled={isDisabled} // Disable file input
                                />
                                <span className="file-custom" />
                            </label>
                        </div>
                    </div>
                    <div className="col-lg-6">
                        <div className="mb-3">
                            <label htmlFor="perLname">User Email</label>
                            <div className="input-area">
                                <input
                                    type="text"
                                    id="perLname"
                                    name="UserEmail"
                                    placeholder="Enter Your Email"
                                    value={editprofiledata.UserEmail} // Set value from state
                                    onChange={handleInputChange} // Handle change
                                    disabled={isDisabled}
                                />
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-6">
                        <div className="mb-3">
                            <label htmlFor="birth">Country Name</label>
                            <div className="input-area">
                                <input
                                    type="text"
                                    id="birth"
                                    name="CountryName"
                                    placeholder="Enter Country Name"
                                    value={editprofiledata.CountryName} // Set value from state
                                    onChange={handleInputChange} // Handle change
                                    disabled={isDisabled}
                                />
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-6">
                        <div className="mb-3">
                            <label htmlFor="dob">Date Of Birth</label>
                            <div className="input-area">
                                <input
                                    style={{ color: "rgba(251, 37, 118, 0.8)" }}
                                    type="date"
                                    id="dob"
                                    name="DateOfBirth"
                                    value={editprofiledata.DateOfBirth} // Set value from state
                                    onChange={handleInputChange} // Handle change
                                    disabled={isDisabled}
                                />
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-6">
                        <div className="mb-3">
                            <label htmlFor="gender">Gender</label>
                            <div className="input-area">
                                <input
                                    type="text"
                                    id="gender"
                                    name="Gender"
                                    placeholder="Enter Gender"
                                    value={editprofiledata.Gender} // Set value from state
                                    onChange={handleInputChange} // Handle change
                                    disabled={isDisabled}
                                />
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-6">
                        <div className="text-center" style={{ marginTop: "35px" }}>
                            <button
                                type="button"
                                className="rounded-pill btn custom-btn-primary primary-btn-effect d-inline-flex justify-content-center align-items-center px-5"
                                onClick={handleEditClick} // Call the function to enable inputs
                            >
                                Edit Details
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    );
};

export default Hello;
