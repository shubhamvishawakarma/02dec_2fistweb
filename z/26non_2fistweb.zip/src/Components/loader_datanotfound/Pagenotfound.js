import React from 'react'

const Pagenotfound = () => {
  return (
    <>
      <div className='col-12 row  justify-content-center mt-5 mb-5'>
        <div className='col-lg-4 col-12 text-center'>
          <div>
            {/* <img style={{ borderRadius: "80%" }} width={"40%"} className='img-fluid' src="./imglist/datanotfound_logo.png" alt /> */}
          </div>
          <h6 className='mt-2'>Data Not Found</h6>
        </div>
      </div>
    </>
  )
}

export default Pagenotfound